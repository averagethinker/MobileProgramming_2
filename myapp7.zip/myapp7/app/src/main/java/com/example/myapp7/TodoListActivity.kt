// TodoListActivity.kt
package com.example.mainapp

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapp7.R

class TodoListActivity : AppCompatActivity() {

    private lateinit var textViewWelcome: TextView
    private lateinit var spinnerFilter: Spinner
    private lateinit var editTextTask: EditText
    private lateinit var buttonAddTask: Button
    private lateinit var recyclerViewTasks: RecyclerView

    private val tasks = mutableListOf<Task>()
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_todo_list)

        textViewWelcome = findViewById(R.id.textViewWelcome)
        spinnerFilter = findViewById(R.id.spinnerFilter)
        editTextTask = findViewById(R.id.editTextTask)
        buttonAddTask = findViewById(R.id.buttonAddTask)
        recyclerViewTasks = findViewById(R.id.recyclerViewTasks)

        val welcomeMessage = intent.getStringExtra("welcomeMessage") ?: "Welcome"
        textViewWelcome.text = welcomeMessage

        // Setup Spinner
        ArrayAdapter.createFromResource(
            this,
            R.array.filter_options,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerFilter.adapter = adapter
        }

        // Setup RecyclerView
        recyclerViewTasks.layoutManager = LinearLayoutManager(this)
        adapter = TaskAdapter(tasks)
        recyclerViewTasks.adapter = adapter

        // Setup Button Click Listener
        buttonAddTask.setOnClickListener {
            val taskDescription = editTextTask.text.toString()
            if (taskDescription.isNotEmpty()) {
                val task = Task(taskDescription)
                tasks.add(task)
                adapter.notifyDataSetChanged()
                editTextTask.text.clear()
            }
        }

        // Setup Spinner Item Selected Listener
        spinnerFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                filterTasks(parent.getItemAtPosition(position) as String)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun filterTasks(filter: String) {
        val filteredTasks = when (filter) {
            "Completed" -> tasks.filter { it.isCompleted }
            "Incomplete" -> tasks.filter { !it.isCompleted }
            else -> tasks
        }
        adapter = TaskAdapter(filteredTasks)
        recyclerViewTasks.adapter = adapter
    }
}
